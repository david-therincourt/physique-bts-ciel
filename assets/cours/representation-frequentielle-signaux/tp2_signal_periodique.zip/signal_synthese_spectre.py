import numpy as np
import matplotlib.pyplot as plt
from math import pi, sqrt

##### PARAMETRES #####
filename = "signal_periodique"
N = 4000                       # Nombre de points
f = 150
T = 1/f
w = 2*pi*f

##### SYNTHESE DU SIGNAL #####
t = np.linspace(0,T,N)           # tps en milliseconde
u = np.zeros(N,np.double)        # Tension

A   = np.array([1.2, 5.0,  3.7,  0.0,  2.8,  0.7, 0.0, 1.3])
phi = np.array([0.0, 0.0, -0.5, +0.0, 0.33, -0.2, 0.0, 0.0])

u = ( A[0] +
      A[1]*np.sin(1*w*t + phi[1]) +
      A[2]*np.sin(2*w*t + phi[2]) +
      A[3]*np.sin(3*w*t + phi[3]) +
      A[4]*np.sin(4*w*t + phi[4]) +
      A[5]*np.sin(5*w*t + phi[5]) +
      A[6]*np.sin(6*w*t + phi[6]) +
      A[7]*np.sin(7*w*t + phi[7])
    )

moy = np.average(u)         # Calcul valeur moyenne
eff = sqrt(np.mean(u**2))   # Calcul valeur efficace
print("<u> =" , moy, "U = ", eff)

##### SPECTRE RMS ######
freq = [i*f for i in range(len(A))]  # Fréquence harmonique
U_V = A/np.sqrt(2)                   # Niveau RMS en V
U_dBV = 20*np.log10(U_V)             # Niveau RMS en dBV


###### COURBES #######
plt.rcParams["figure.figsize"] = (8,10)  # width, height in inches (100 dpi)
plt.subplots_adjust(hspace=0.15, left=0.10, bottom=0.06, right=0.95, top=0.94 ) # Position en %

plt.subplot(311)
plt.axhspan(-10,+10, color="orange", alpha=0.2)
plt.plot(t*1000, u)
plt.axhline(0,color="black")
plt.title("")
plt.xlabel("t (ms)")
plt.ylabel("u (V)")
plt.grid()

plt.subplot(312)
plt.stem(freq, U_V) 
plt.axhline(0,color="black")
plt.title("")
plt.xlabel("f (Hz)")
plt.ylabel("V RMS")
plt.grid()

plt.subplot(313)
plt.stem(freq, U_dBV, bottom = -20) 
plt.axhline(-20, color="black")
plt.title("")
plt.xlabel("f (Hz)")
plt.ylabel("dBV RMS")
plt.grid()

plt.savefig(filename+".png")
plt.show()


##### Export Siglent GBF  #####
data_length = N
frequency = f
amp = max(u)*2             # Tension max VPP (crête à crête)
offset = 0                 # Offset
phase = 0

if amp<=20:  # Limitation du GBF à 20 VPP
    fichier = open(filename+".csv", "w")
    fichier.write("data length,{}\n".format(data_length))
    fichier.write("frequency,{:.9f}\n".format(frequency))
    fichier.write("amp,{:.9f}\n".format(amp))
    fichier.write("offset,{:.9f}\n".format(offset))
    fichier.write("phase,{:.9f}\n".format(phase))
    for i in range(7):
        fichier.write("\n")
    fichier.write("xpos,value\n")
    for i in range(len(t)):
        fichier.write("{:.5e},{:.5e}\n".format(t[i], u[i]))
    fichier.close()
else:
    print("Pas d'exportation en CSV : amplitude supérieure à 20 VPP !")


